import React, { useState } from "react"
import "./addKeeper.css"
import axios from "axios"

const AddKeeper = ({ setKeeperList }) => {

    const [keeperObj, setKeeperObj] = useState({
        title: "",
        description:""
    })

    const handleChange = e => {
        const { name, value } = e.target
        setKeeperObj({
            ...keeperObj,                   
            [name]: value                               //here now we will asign the value to the targeted state variable
        })
    }

    //When (Add) button is clicked this function will going to be run
    const add = () => {
        if(keeperObj.title) {
            axios.post("http://localhost:3001/api/addNew", keeperObj)       //using axios sending post request to api url
            .then(res => setKeeperList(res.data))
            setKeeperObj({
                title: "",
                description:""
            })
        }
    }

    return (
        <div className="addKeeper">
           <input
                className="inputBox titleInput"
                type="text"
                name="title"
                autoComplete="off"
                placeholder="Add Title"
                onChange={handleChange}
                value={keeperObj.title}
            />
            <textarea 
                className="inputBox description"
                name="description"
                placeholder="Add Description Here"
                onChange={handleChange}
                value={keeperObj.description}
            />
            <div className="addButton" onClick={add}>Add</div>
        </div>
    )
}

export default AddKeeper